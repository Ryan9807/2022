#量化地评价不同二值化方法优劣
import os
import cv2
import numpy as np
import math

def psnr(img1,img2):
    mse = np.mean((img1 / 1.0 - img2 / 1.0) ** 2)
    if mse < 1e-10:
        return 100
    psnr = 10 * math.log10(255*255/mse)
    return psnr
gray = cv2.imread(r"D:/StudyImage/study-1007/R2.2/001.18.png", cv2.IMREAD_GRAYSCALE)
img_GT = cv2.imread(r"D:/StudyImage/study-1007/R2.2/001.18-GT.png", cv2.IMREAD_GRAYSCALE)
#GAUSSIAN_C
img = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 5)
print(psnr(img,img_GT))
#MEAN_C
img1 = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 5)
print(psnr(img1,img_GT))
#手动设置阈值
img2 = cv2.threshold(gray,200,255,cv2.THRESH_BINARY)[1]
print(psnr(img2,img_GT))
#Otsu
img3= cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
print(psnr(img3,img_GT))
