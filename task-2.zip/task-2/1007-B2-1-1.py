#返回指定文件夹下（含子目录）以指定后缀结尾的文件路径列表
import os

def get_all_files_pth(dir:str,suffix:str = '*'):
    Filelist = []
    for root, dirs, files in os.walk(dir):   #每次遍历的对象都是返回的是一个三元组(root,dirs,files)
        # root 所指的是当前正在遍历的这个文件夹的本身的地址
        # dirs 是一个 list ，内容是该文件夹中所有的目录的名字(不包括子目录)
        # files 同样是 list , 内容是该文件夹中所有的文件(不包括子目录)
        for filename in files:
            # 文件名列表，包含完整路径
            if filename.endswith(suffix):
                Filelist.append(os.path.join(root + '/', filename))
    return Filelist

dirPath = r"D:/StudyFile/1007"
fileSuffix = 'png'
Filelist = get_all_files_pth(dirPath + '/',fileSuffix)
print(len(Filelist))
for file in  Filelist :
    print(file)