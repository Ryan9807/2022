#行切分
import os
import cv2
import numpy as np

def hor_projection(img:np.ndarray)->list:
    rst = []
    h, w = img.shape[:2]  #返回图片的(高,宽)
    for i in range(h):
        hor_num = 0
        for j in range(w):
            if img[i][j] == 255:
                hor_num = hor_num + 1
        rst.append(hor_num)
    return rst
def crop_according_to_threshold(signal:list,t:int)->list:
    rst = []
    s = 0
    e = 0
    temp = 0
    for i in range(len(signal)):
        if(signal[i] > t and temp == 0):
            s = i
            temp = 1
        elif(signal[i] <= t and temp == 1):
            e = i-1
            temp = 0
            rst.append((s,e))
    return rst

gray = cv2.imread(r"D:/StudyImage/study-1007/A2.1/tahiti.png", cv2.IMREAD_GRAYSCALE)
img = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 5)
#白底黑字转换为黑底白字
img = 255 - img
#获取图片高，宽
h, w = img.shape[:2]
#行投影
list = hor_projection(img)
#文本行起始、结束位置列表
row_list = crop_according_to_threshold(list,0)
#切分文本行
for i in range(len(row_list)):
    row_img = img[row_list[i][0]:row_list[i][1],0:w]
    cv2.imwrite(r"D:/StudyFile/1007/A2.2_result/ImageName_" + str(i) + '.png', row_img)




