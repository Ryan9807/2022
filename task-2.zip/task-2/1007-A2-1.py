#求行投影
import os
import cv2
import numpy as np
#判断图片为白底黑字或黑底白字
def is_bin_bg_white(img):

    h = img.shape[0] #获取图片长，宽
    w = img.shape[1]
    num = 0
    num_white = 0
    for a in range(h):
        for b in range(w):
            if img[a][b] >= 0:
                num = num + 1
                if img[a][b] == 255:
                    num_white = num_white + 1
    if num_white > num / 2:
        return True
    else:
        return False
#行投影
def hor_projection(img:np.ndarray)->list:
    rst = []
    h, w = img.shape[:2]  #返回图片的(高,宽)
    for i in range(h):
        hor_num = 0
        for j in range(w):
            if img[i][j] == 255:
                hor_num = hor_num + 1
        rst.append(hor_num)
    return rst
#可视化
def line_visualization(paint:list):
    paint = np.zeros(img.shape, dtype=np.uint8)
    for i in range(len(result)):
        for j in range(result[i]):
            paint[i][j] = 255
    return paint

gray = cv2.imread(r"D:/StudyImage/study-1007/A2.1/tahiti.png", cv2.IMREAD_GRAYSCALE)
#图片二值化
img = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 5)
#白底黑字转换为黑底白字
if is_bin_bg_white(img):
    img = 255 - img
cv2.imwrite(r"D:/StudyFile/1007/A2.1_result/img.png", img)
#行投影
result = hor_projection(img)
#行投影可视化
paint = line_visualization(result)
#保存结果
cv2.imwrite(r"D:/StudyFile/1007/A2.1_result/result.png", paint)
cv2.namedWindow('result',cv2.WINDOW_NORMAL)       #设置窗口属性，保持图片完整
cv2.imshow('result',paint)
cv2.waitKey(0)