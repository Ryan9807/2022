#自行下载文件夹下所有图像，并全部转换为黑底白字
import os
import cv2
#判断图片黑底白字还是白底黑字
def is_bin_bg_white(img):

    h = img.shape[0] #获取图片长，宽
    w = img.shape[1]
    num = 0
    num_white = 0
    for a in range(h):
        for b in range(w):
            if img[a][b] >= 0:
                num = num + 1
                if img[a][b] == 255:
                    num_white = num_white + 1
    if num_white > num / 2:
        return True
    else:
        return False
#获取图片路径
def get_fpths_from_dir(dir, suffix, Filelist):
    for fileName in os.listdir(dir):  # 获取文件名
        if fileName.endswith(suffix):  # 判断是否为图片
            Filelist.append(os.path.join(dir + '/', fileName))
    return Filelist
#创建文件夹
def create_file(path):
    #os.path.exists(path)判断一个目录是否存在
    #os.mkdir(path)创建目录
    isExists=os.path.exists(path)
    if not isExists:
        os.mkdir(path)
        print(path+'创建成功')
        return True
    else:
        print(path+'文件夹已存在,创建文件夹失败')
        return False
#判断图片类型
def  is_imgType_str(path):
    if type(path) is str:
        # print("str")
        return True
    else:
        print("图片类型错误")



dirPath = r"D:/StudyData/dataset/train/image"
resultPath = r"D:/StudyFile/1007/R2.1_result"
fileSuffix = 'jpg'
filelist = get_fpths_from_dir(dirPath,fileSuffix,[])

if create_file(resultPath):
    for imgpath in filelist:
        img = cv2.imread(imgpath, cv2.IMREAD_GRAYSCALE)
        result = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 5)
        imgname = os.path.splitext(os.path.basename(imgpath))[0]  # 获取图片名
        if is_imgType_str(imgpath):
            if is_bin_bg_white(result):
                result = 255 - result #转换为黑底白字
                cv2.imwrite(resultPath + '/' + imgname + '.' + fileSuffix, result) #保存图片到文件夹
            else:
                cv2.imwrite(resultPath + '/' + imgname + '.' + fileSuffix, result)
        else:
            cv2.imwrite(resultPath + '/' + imgname + '.' + fileSuffix, result)
    print("转换完成")






