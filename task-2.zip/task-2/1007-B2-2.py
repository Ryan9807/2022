#0，1/2，1，，0，1/4
import os
import math
import numpy as np
def function(x):
    if x >= 0:  #x越大e^(-x)越趋近于0，不会溢出
        return 1.0 / (1 + np.power(np.e, -x))
    else:  # 为负数的时候，避免数据溢出，将式子转换为e^x/(1+e^x)
        return np.power(np.e, x) / (1 + np.power(np.e, x))

x = -10000
while x < 1000:
    if x < -0.01:
        x = x/10
    elif x == -0.01:
        x = 0
        print("f(" + str(x) + ") = " + str(function(x)))
        x = 0.01
    elif x >= 0:
        x = x*10
    print("f(" + str(x) + ") = " + str(function(x)))